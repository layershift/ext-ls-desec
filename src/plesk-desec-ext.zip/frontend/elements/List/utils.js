import React from 'react';
import { states } from '../../utils/states';
import { Checkbox, Link, Label, Switch, Text} from '@plesk/ui-library';
import { createElement, Component } from '@plesk/plesk-ext-sdk';
import { isDisabled } from "../../utils/methods";

export const handleSelectAll = function () {
    this.setState((prevState) => {
        const activeDomainIds = prevState.domains
            .filter(domain => domain["dns-status"] === true)
            .map(domain => domain["domain-id"]);

        return {
            selectedDomains: prevState.selectedDomains.size === activeDomainIds.length
                ? new Set()
                : new Set(activeDomainIds)
        };
    });
};

export const handleCheckboxChange = function (domainId) {
    this.setState((prevState) => {
        const updatedSelection = new Set(prevState.selectedDomains);
        updatedSelection.has(domainId) ? updatedSelection.delete(domainId) : updatedSelection.add(domainId);
        return {selectedDomains: updatedSelection};
    });
};

export const handleSyncChange = function (domainId) {
    this.setState((prevState) => {
        const updatedSelection = { ...prevState.autoSyncStatus };
        updatedSelection[domainId] = !updatedSelection[domainId];

        const changedSelections = Object.keys(updatedSelection).reduce((acc, id) => {
            if (updatedSelection[id] !== prevState.autoSyncStatus[id]) {
                acc[id] = updatedSelection[id];
            }
            return acc;
        }, {});

        console.log("Changed Selections:", changedSelections);
        return { autoSyncStatus: updatedSelection, changedSelections};
    // }
    //     () => {
    //     saveAutoSyncStatus.call(this);
    });
};

//
