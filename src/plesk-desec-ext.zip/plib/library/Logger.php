<?php

use pm_Settings;

class Logger
{

    public function addLog($desc, $data = "") {
        // TODO: modify logging per Slack discussion
        if(pm_Settings::get('ext_ls_desec_log_verbosity') === "verbose") {
            file_put_contents(pm_Settings::get("ext_ls_desec_log_file"), "[ " . date('Y-m-d H:i') . " ] DEBUG [ ext-ls-desec/debug ] "  . $desc . ": " . print_r($data, true), FILE_APPEND);
        }

    }

}