<?php
$messages = [
    'app' => [
        'index' => [
            'title' => 'Sync DNS records with deSEC!',
        ],
    ],
];